package controlers;
import models.Bill; 
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;



public class BillControlers {

private List<Bill> bills = new ArrayList<>();
    private int nextId = 1;

    
    public Bill createBill(Date date, double total) {
        Bill bill = new Bill(nextId, date, total);
        bills.add(bill);
        nextId++;
        return bill;
    }

    
    public Bill getBillById(int id) {
        for (Bill bill : bills) {
            if (bill.getId() == id) {
                return bill;
            }
        }
        return null; 
    }

    
    public boolean updateBill(Bill updatedBill) {
        for (int i = 0; i < bills.size(); i++) {
            if (bills.get(i).getId() == updatedBill.getId()) {
                bills.set(i, updatedBill);
                return true;
            }
        }
        return false; 
    }

    
    public boolean deleteBill(int id) {
        for (Bill bill : bills) {
            if (bill.getId() == id) {
                bills.remove(bill);
                return true;
            }
        }
        return false; 
    }

    public List<Bill> getAllBills() {
        return bills;
    }


    public class BillControllersTest {
    private BillControlers billControllers;

    @BeforeEach
    void setUp() {
        billControllers = new BillControlers();
    }

    @Test
    void testCreateBill() {
        Date date = new Date();
        double total = 100.0;
        Bill bill = billControllers.createBill(date, total);

        assertNotNull(bill);
        assertEquals(date, bill.getDate());
        assertEquals(total, bill.getTotal());
    }

    @Test
    void testGetBillById() {
        Date date = new Date();
        double total = 100.0;
        Bill createdBill = billControllers.createBill(date, total);
        int id = createdBill.getId();

        Bill retrievedBill = billControllers.getBillById(id);

        assertNotNull(retrievedBill);
        assertEquals(createdBill, retrievedBill);
    }

    @Test
    void testUpdateBill() {
        Date date = new Date();
        double total = 100.0;
        Bill bill = billControllers.createBill(date, total);
        int id = bill.getId();

        Date newDate = new Date();
        double newTotal = 200.0;
        Bill updatedBill = new Bill(id, newDate, newTotal);

        assertTrue(billControllers.updateBill(updatedBill));

        Bill retrievedBill = billControllers.getBillById(id);

        assertEquals(newDate, retrievedBill.getDate());
        assertEquals(newTotal, retrievedBill.getTotal());
    }

    @Test
    void testDeleteBill() {
        Date date = new Date();
        double total = 100.0;
        Bill bill = billControllers.createBill(date, total);
        int id = bill.getId();

        assertTrue(billControllers.deleteBill(id));

        Bill retrievedBill = billControllers.getBillById(id);

        assertNull(retrievedBill);
    }

    @Test
    void testGetAllBills() {
        Date date1 = new Date();
        Date date2 = new Date();
        double total1 = 100.0;
        double total2 = 200.0;
        billControllers.createBill(date1, total1);
        billControllers.createBill(date2, total2);

        List<Bill> allBills = billControllers.getAllBills();

        assertNotNull(allBills);
        assertEquals(2, allBills.size());
    }
}

}
