package controlers; 
import models.Branch; 
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class BranchControlers {

 private List<Branch> branches = new ArrayList<>();
    private int nextId = 1;

   
    public Branch createBranch(String name, String address, String phone) {
        Branch branch = new Branch(nextId, name, address, phone);
        branches.add(branch);
        nextId++;
        return branch;
    }

   
    public Branch getBranchById(int id) {
        for (Branch branch : branches) {
            if (branch.getId() == id) {
                return branch;
            }
        }
        return null; 
    }


    public boolean updateBranch(Branch updatedBranch) {
        for (int i = 0; i < branches.size(); i++) {
            if (branches.get(i).getId() == updatedBranch.getId()) {
                branches.set(i, updatedBranch);
                return true;
            }
        }
        return false; 
    }

   
    public boolean deleteBranch(int id) {
        for (Branch branch : branches) {
            if (branch.getId() == id) {
                branches.remove(branch);
                return true;
            }
        }
        return false;  
    }

    
    public List<Branch> getAllBranches() {
        return branches;
    }

    public class BranchControlersTest {
    private BranchControlers branchControlesrs;

    @BeforeEach
    void setUp() {
        branchControlesrs = new BranchControlers();
    }

    @Test
    void testCreateBranch() {
        String name = "Sucursal A";
        String address = "123 Calle Principal";
        String phone = "555-123-4567";

        Branch branch = branchControlesrs.createBranch(name, address, phone);

        assertNotNull(branch);
        assertEquals(name, branch.getName());
        assertEquals(address, branch.getAddress());
        assertEquals(phone, branch.getPhone());
    }

    @Test
    void testGetBranchById() {
        String name = "Sucursal B";
        String address = "456 Calle Secundaria";
        String phone = "555-987-6543";

        Branch createdBranch = branchControlesrs.createBranch(name, address, phone);
        int id = createdBranch.getId();

        Branch retrievedBranch = branchControlesrs.getBranchById(id);

        assertNotNull(retrievedBranch);
        assertEquals(createdBranch, retrievedBranch);
    }

    @Test
    void testUpdateBranch() {
        String name = "Sucursal C";
        String address = "789 Calle Terciaria";
        String phone = "555-456-7890";

        Branch branch = branchControlesrs.createBranch(name, address, phone);
        int id = branch.getId();

        String newName = "Sucursal D";
        String newAddress = "101 Calle Cuaternaria";
        String newPhone = "555-111-2222";
        Branch updatedBranch = new Branch(id, newName, newAddress, newPhone);

        assertTrue(branchControlesrs.updateBranch(updatedBranch));

        Branch retrievedBranch = branchControlesrs.getBranchById(id);

        assertEquals(newName, retrievedBranch.getName());
        assertEquals(newAddress, retrievedBranch.getAddress());
        assertEquals(newPhone, retrievedBranch.getPhone());
    }

    @Test
    void testDeleteBranch() {
        String name = "Sucursal E";
        String address = "111 Calle Quintaria";
        String phone = "555-333-4444";

        Branch branch = branchControlesrs.createBranch(name, address, phone);
        int id = branch.getId();

        assertTrue(branchRepository.deleteBranch(id));

        Branch retrievedBranch = branchControlesrs.getBranchById(id);

        assertNull(retrievedBranch);
    }

    @Test
    void testGetAllBranches() {
        branchControlesrs.createBranch("Sucursal F", "222 Calle Sextaria", "555-555-5555");
        branchControlesrs.createBranch("Sucursal G", "333 Calle Septenaria", "555-666-6666");

        assertEquals(2, branchControlesrs.getAllBranches().size());
    }
}

}
