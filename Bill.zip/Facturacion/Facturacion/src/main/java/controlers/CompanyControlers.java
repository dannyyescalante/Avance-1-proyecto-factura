package controlers; 
import models.Company; 
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class CompanyControlers {

 private List<Company> companies = new ArrayList<>();
    private int nextId = 1;

    
    public Company createCompany(String name, String address, String mail, String phone) {
        Company company = new Company(nextId, name, address, mail, phone);
        companies.add(company);
        nextId++;
        return company;
    }

    public Company getCompanyById(int id) {
        for (Company company : companies) {
            if (company.getId() == id) {
                return company;
            }
        }
        return null; 
    }

   
    public boolean updateCompany(Company updatedCompany) {
        for (int i = 0; i < companies.size(); i++) {
            if (companies.get(i).getId() == updatedCompany.getId()) {
                companies.set(i, updatedCompany);
                return true;
            }
        }
        return false; 
    }

   
    public boolean deleteCompany(int id) {
        for (Company company : companies) {
            if (company.getId() == id) {
                companies.remove(company);
                return true;
            }
        }
        return false; 
    }

    
    public List<Company> getAllCompanies() {
        return companies;
    }

    public class CompanyControlersTest {
    private CompanyControlers companycontrolers;

    @BeforeEach
    void setUp() {
        CompanyControlers = new companycontrolers();
    }

    @Test
    void testCreateCompany() {
        String name = "Company A";
        String address = "123 Main Street";
        String mail = "company@example.com";
        String phone = "555-123-4567";

        Company company = companycontrolers.createCompany(name, address, mail, phone);

        assertNotNull(company);
        assertEquals(name, company.getName());
        assertEquals(address, company.getAddress());
        assertEquals(mail, company.getMail());
        assertEquals(phone, company.getPhone());
    }

    @Test
    void testGetCompanyById() {
        String name = "Company B";
        String address = "456 Secondary Street";
        String mail = "companyb@example.com";
        String phone = "555-987-6543";

        Company createdCompany = companycontrolers.createCompany(name, address, mail, phone);
        int id = createdCompany.getId();

        Company retrievedCompany = companycontrolers.getCompanyById(id);

        assertNotNull(retrievedCompany);
        assertEquals(createdCompany, retrievedCompany);
    }

    @Test
    void testUpdateCompany() {
        String name = "Company C";
        String address = "789 Tertiary Street";
        String mail = "companyc@example.com";
        String phone = "555-456-7890";

        Company company = companycontrolers.createCompany(name, address, mail, phone);
        int id = company.getId();

        String newName = "Company D";
        String newAddress = "101 Quaternary Street";
        String newMail = "companyd@example.com";
        String newPhone = "555-111-2222";
        Company updatedCompany = new Company(id, newName, newAddress, newMail, newPhone);

        assertTrue(companycontrolers.updateCompany(updatedCompany));

        Company retrievedCompany = companycontrolers.getCompanyById(id);

        assertEquals(newName, retrievedCompany.getName());
        assertEquals(newAddress, retrievedCompany.getAddress());
        assertEquals(newMail, retrievedCompany.getMail());
        assertEquals(newPhone, retrievedCompany.getPhone());
    }

    @Test
    void testDeleteCompany() {
        String name = "Company E";
        String address = "111 Quintenary Street";
        String mail = "companye@example.com";
        String phone = "555-333-4444";

        Company company = companycontrolers.createCompany(name, address, mail, phone);
        int id = company.getId();

        assertTrue(companycontrolers.deleteCompany(id));

        Company retrievedCompany = companycontrolers.getCompanyById(id);

        assertNull(retrievedCompany);
    }

    @Test
    void testGetAllCompanies() {
        companycontrolers.createCompany("Company F", "222 Sextenary Street", "companyf@example.com", "555-555-5555");
        companycontrolers.createCompany("Company G", "333 Septenary Street", "companyg@example.com", "555-666-6666");

        assertEquals(2, companycontrolers.getAllCompanies().size());
    }
}

}