package controlers; 
import models.Costomer; 
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class CostumerControlers {

private List<Customer> customers = new ArrayList<>();
    private int nextId = 1;

    public Customer createCustomer(String address) {
        Customer customer = new Customer(nextId, address);
        customers.add(customer);
        nextId++;
        return customer;
    }

    public Customer getCustomerById(int id) {
        for (Customer customer : customers) {
            if (customer.getId() == id) {
                return customer;
            }
        }
        return null; 
    }

    public boolean updateCustomer(Customer updatedCustomer) {
        for (int i = 0; i < customers.size(); i++) {
            if (customers.get(i).getId() == updatedCustomer.getId()) {
                customers.set(i, updatedCustomer);
                return true;
            }
        }
        return false;
    }

   
    public boolean deleteCustomer(int id) {
        for (Customer customer : customers) {
            if (customer.getId() == id) {
                customers.remove(customer);
                return true;
            }
        }
        return false; 
    }


    public List<Customer> getAllCustomers() {
        return customers;
    }

    public class CustomerControlersTest {
    private CustomerControlers customerControlers;

    @BeforeEach
    void setUp() {
        customerControlers= new CustomerControlers();
    }

    @Test
    void testCreateCustomer() {
        String address = "123 Main Street";

        Customer customer = customerControlers.createCustomer(address);

        assertNotNull(customer);
        assertEquals(address, customer.getAddress());
    }

    @Test
    void testGetCustomerById() {
        String address = "456 Secondary Street";

        Customer createdCustomer = customerControlers.createCustomer(address);
        int id = createdCustomer.getId();

        Customer retrievedCustomer = customerControlers.getCustomerById(id);

        assertNotNull(retrievedCustomer);
        assertEquals(createdCustomer, retrievedCustomer);
    }

    @Test
    void testUpdateCustomer() {
        String address = "789 Tertiary Street";

        Customer customer = customerControlers.createCustomer(address);
        int id = customer.getId();

        String newAddress = "101 Quaternary Street";
        Customer updatedCustomer = new Customer(id, newAddress);

        assertTrue(customerControlers.updateCustomer(updatedCustomer));

        Customer retrievedCustomer = customerControlers.getCustomerById(id);

        assertEquals(newAddress, retrievedCustomer.getAddress());
    }

    @Test
    void testDeleteCustomer() {
        String address = "111 Quintenary Street";

        Customer customer = customerControlers.createCustomer(address);
        int id = customer.getId();

        assertTrue(customerControlers.deleteCustomer(id));

        Customer retrievedCustomer = customerControlers.getCustomerById(id);

        assertNull(retrievedCustomer);
    }

    @Test
    void testGetAllCustomers() {
        customerControlers.createCustomer("222 Sextenary Street");
        customerControlers.createCustomer("333 Septenary Street");

        assertEquals(2, customerControlers.getAllCustomers().size());
    }
}

}