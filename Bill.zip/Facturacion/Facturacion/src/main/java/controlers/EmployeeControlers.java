package controlers; 
import models.Employee; 
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class EmployeeControlers {

    private List<Employee> employees = new ArrayList<>();
    private int nextId = 1;

   
    public Employee createEmployee(String name, String position, double salary) {
        Employee employee = new Employee(nextId, name, position, salary);
        employees.add(employee);
        nextId++;
        return employee;
    }

    public Employee getEmployeeById(int id) {
        for (Employee employee : employees) {
            if (employee.getId() == id) {
                return employee;
            }
        }
        return null; 
    }

    
    public boolean updateEmployee(Employee updatedEmployee) {
        for (int i = 0; i < employees.size(); i++) {
            if (employees.get(i).getId() == updatedEmployee.getId()) {
                employees.set(i, updatedEmployee);
                return true;
            }
        }
        return false; 
    }

    
    public boolean deleteEmployee(int id) {
        for (Employee employee : employees) {
            if (employee.getId() == id) {
                employees.remove(employee);
                return true;
            }
        }
        return false; 
    }

   
    public List<Employee> getAllEmployees() {
        return employees;
    }

    public class EmployeeControlersTest {
    private EmployeeControlers employeeControlers;

    @BeforeEach
    void setUp() {
        EmployeeControlers = new EmployeeControlers();
    }

    @Test
    void testCreateEmployee() {
        String name = "John Doe";
        String position = "Manager";
        double salary = 50000.0;

        Employee employee = employeeControlers.createEmployee(name, position, salary);

        assertNotNull(employee);
        assertEquals(name, employee.getName());
        assertEquals(position, employee.getPosition());
        assertEquals(salary, employee.getSalary());
    }

    @Test
    void testGetEmployeeById() {
        String name = "Jane Smith";
        String position = "Developer";
        double salary = 60000.0;

        Employee createdEmployee = employeeControlers.createEmployee(name, position, salary);
        int id = createdEmployee.getId();

        Employee retrievedEmployee = employeeControlers.getEmployeeById(id);

        assertNotNull(retrievedEmployee);
        assertEquals(createdEmployee, retrievedEmployee);
    }

    @Test
    void testUpdateEmployee() {
        String name = "Alice Johnson";
        String position = "Designer";
        double salary = 55000.0;

        Employee employee = employeeControlers.createEmployee(name, position, salary);
        int id = employee.getId();

        String newName = "Bob Williams";
        String newPosition = "Product Manager";
        double newSalary = 70000.0;
        Employee updatedEmployee = new Employee(id, newName, newPosition, newSalary);

        assertTrue(employeeControlers.updateEmployee(updatedEmployee));

        Employee retrievedEmployee = employeeControlers.getEmployeeById(id);

        assertEquals(newName, retrievedEmployee.getName());
        assertEquals(newPosition, retrievedEmployee.getPosition());
        assertEquals(newSalary, retrievedEmployee.getSalary());
    }

    @Test
    void testDeleteEmployee() {
        String name = "Eve Anderson";
        String position = "Tester";
        double salary = 45000.0;

        Employee employee = employeeControlers.createEmployee(name, position, salary);
        int id = employee.getId();

        assertTrue(employeeControlers.deleteEmployee(id));

        Employee retrievedEmployee = employeeControlers.getEmployeeById(id);

        assertNull(retrievedEmployee);
    }

    @Test
    void testGetAllEmployees() {
        employeeControlers.createEmployee("Grace Davis", "QA Engineer", 48000.0);
        employeeControlers.createEmployee("Michael Wilson", "Data Analyst", 62000.0);

        assertEquals(2, employeeControlers.getAllEmployees().size());
    }
}

}