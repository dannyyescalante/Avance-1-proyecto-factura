package controlers; 
import models.Product; 
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ProductControlers {

 private List<Product> products = new ArrayList<>();
    private int nextId = 1;

    
    public Product createProduct(String name, String description, double price, int stock) {
        Product product = new Product(nextId, name, description, price, stock);
        products.add(product);
        nextId++;
        return product;
    }

    
    public Product getProductById(int id) {
        for (Product product : products) {
            if (product.getId() == id) {
                return product;
            }
        }
        return null; 
    }

    
    public boolean updateProduct(Product updatedProduct) {
        for (int i = 0; i < products.size(); i++) {
            if (products.get(i).getId() == updatedProduct.getId()) {
                products.set(i, updatedProduct);
                return true;
            }
        }
        return false; 
    }

  
    public boolean deleteProduct(int id) {
        for (Product product : products) {
            if (product.getId() == id) {
                products.remove(product);
                return true;
            }
        }
        return false; 
    }


    public List<Product> getAllProducts() {
        return products;
    }

    public class ProductControlersTest {
    private ProductControlers productControlers;

    @BeforeEach
    void setUp() {
        productControlers = new ProductControlers();
    }

    @Test
    void testCreateProduct() {
        String name = "Product A";
        String description = "Description for Product A";
        double price = 50.0;
        int stock = 100;

        Product product = productControlers.createProduct(name, description, price, stock);

        assertNotNull(product);
        assertEquals(name, product.getName());
        assertEquals(description, product.getDescription());
        assertEquals(price, product.getPrice());
        assertEquals(stock, product.getStock());
    }

    @Test
    void testGetProductById() {
        String name = "Product B";
        String description = "Description for Product B";
        double price = 60.0;
        int stock = 200;

        Product createdProduct = productControlers.createProduct(name, description, price, stock);
        int id = createdProduct.getId();

        Product retrievedProduct = productControlers.getProductById(id);

        assertNotNull(retrievedProduct);
        assertEquals(createdProduct, retrievedProduct);
    }

    @Test
    void testUpdateProduct() {
        String name = "Product C";
        String description = "Description for Product C";
        double price = 70.0;
        int stock = 300;

        Product product = productControlers.createProduct(name, description, price, stock);
        int id = product.getId();

        String newName = "Product D";
        String newDescription = "Description for Product D";
        double newPrice = 80.0;
        int newStock = 400;
        Product updatedProduct = new Product(id, newName, newDescription, newPrice, newStock);

        assertTrue(productControlers.updateProduct(updatedProduct));

        Product retrievedProduct = productControlers.getProductById(id);

        assertEquals(newName, retrievedProduct.getName());
        assertEquals(newDescription, retrievedProduct.getDescription());
        assertEquals(newPrice, retrievedProduct.getPrice());
        assertEquals(newStock, retrievedProduct.getStock());
    }

    @Test
    void testDeleteProduct() {
        String name = "Product E";
        String description = "Description for Product E";
        double price = 90.0;
        int stock = 500;

        Product product = productControlers.createProduct(name, description, price, stock);
        int id = product.getId();

        assertTrue(productControlers.deleteProduct(id));

        Product retrievedProduct = productControlers.getProductById(id);

        assertNull(retrievedProduct);
    }

    @Test
    void testGetAllProducts() {
        productControlers.createProduct("Product F", "Description for Product F", 100.0, 600);
        productControlers.createProduct("Product G", "Description for Product G", 110.0, 700);

        assertEquals(2, productControlers.getAllProducts().size());
    }
}

}