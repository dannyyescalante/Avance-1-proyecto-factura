package controlers; 
import models.Purchase; 
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class PurchaseControlers {

private List<Purchase> purchases = new ArrayList<>();
    private int nextId = 1;

  
    public Purchase createPurchase(Date date, double total) {
        Purchase purchase = new Purchase(nextId, date, total);
        purchases.add(purchase);
        nextId++;
        return purchase;
    }

    
    public Purchase getPurchaseById(int id) {
        for (Purchase purchase : purchases) {
            if (purchase.getId() == id) {
                return purchase;
            }
        }
        return null; 
    }

    
    public boolean updatePurchase(Purchase updatedPurchase) {
        for (int i = 0; i < purchases.size(); i++) {
            if (purchases.get(i).getId() == updatedPurchase.getId()) {
                purchases.set(i, updatedPurchase);
                return true;
            }
        }
        return false; 
    }

    
    public boolean deletePurchase(int id) {
        for (Purchase purchase : purchases) {
            if (purchase.getId() == id) {
                purchases.remove(purchase);
                return true;
            }
        }
        return false; 
    }

  
    public List<Purchase> getAllPurchases() {
        return purchases;
    }

    public class PurchaseControlersTest {
    private PurchaseControlers purchaseControlers;

    @BeforeEach
    void setUp() {
        purchaseControlers = new PurchaseControlers();
    }

    @Test
    void testCreatePurchase() {
        Date date = new Date();
        double total = 100.0;

        Purchase purchase = purchaseControlers.createPurchase(date, total);

        assertNotNull(purchase);
        assertEquals(date, purchase.getDate());
        assertEquals(total, purchase.getTotal());
    }

    @Test
    void testGetPurchaseById() {
        Date date = new Date();
        double total = 200.0;

        Purchase createdPurchase = purchaseControlers.createPurchase(date, total);
        int id = createdPurchase.getId();

        Purchase retrievedPurchase = purchaseControlers.getPurchaseById(id);

        assertNotNull(retrievedPurchase);
        assertEquals(createdPurchase, retrievedPurchase);
    }

    @Test
    void testUpdatePurchase() {
        Date date = new Date();
        double total = 300.0;

        Purchase purchase = purchaseControlers.createPurchase(date, total);
        int id = purchase.getId();

        Date newDate = new Date();
        double newTotal = 400.0;
        Purchase updatedPurchase = new Purchase(id, newDate, newTotal);

        assertTrue(purchaseControlers.updatePurchase(updatedPurchase));

        Purchase retrievedPurchase = purchaseControlers.getPurchaseById(id);

        assertEquals(newDate, retrievedPurchase.getDate());
        assertEquals(newTotal, retrievedPurchase.getTotal());
    }

    @Test
    void testDeletePurchase() {
        Date date = new Date();
        double total = 500.0;

        Purchase purchase = purchaseControlers.createPurchase(date, total);
        int id = purchase.getId();

        assertTrue(purchaseControlers.deletePurchase(id));

        Purchase retrievedPurchase = purchaseControlers.getPurchaseById(id);

        assertNull(retrievedPurchase);
    }

    @Test
    void testGetAllPurchases() {
        purchaseControlers.createPurchase(new Date(), 600.0);
        purchaseControlers.createPurchase(new Date(), 700.0);

        List<Purchase> purchases = purchaseControlers.getAllPurchases();

        assertEquals(2, purchases.size());
    }
}

}