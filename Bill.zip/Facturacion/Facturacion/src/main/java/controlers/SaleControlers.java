package controlers; 
import models.Sale; 
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class SaleControlers {

private List<Sale> sales = new ArrayList<>();
    private int nextId = 1;

   
    public Sale createSale(Date date, double subtotal) {
        Sale sale = new Sale(date, nextId, subtotal);
        sales.add(sale);
        nextId++;
        return sale;
    }

    
    public Sale getSaleById(int id) {
        for (Sale sale : sales) {
            if (sale.getId() == id) {
                return sale;
            }
        }
        return null; 
    }

    public boolean updateSale(Sale updatedSale) {
        for (int i = 0; i < sales.size(); i++) {
            if (sales.get(i).getId() == updatedSale.getId()) {
                sales.set(i, updatedSale);
                return true;
            }
        }
        return false; 
    }

    public boolean deleteSale(int id) {
        for (Sale sale : sales) {
            if (sale.getId() == id) {
                sales.remove(sale);
                return true;
            }
        }
        return false; 
    }

    public List<Sale> getAllSales() {
        return sales;
    }

    public class SaleControlersTest {
    private SaleControlers saleControlers;

    @BeforeEach
    void setUp() {
        saleControlers = new SaleControlers();
    }

    @Test
    void testCreateSale() {
        Date date = new Date();
        double subtotal = 100.0;

        Sale sale = saleControlers.createSale(date, subtotal);

        assertNotNull(sale);
        assertEquals(date, sale.getDate());
        assertEquals(subtotal, sale.getSubtotal());
    }

    @Test
    void testGetSaleById() {
        Date date = new Date();
        double subtotal = 200.0;

        Sale createdSale = saleControlers.createSale(date, subtotal);
        int id = createdSale.getId();

        Sale retrievedSale = saleControlers.getSaleById(id);

        assertNotNull(retrievedSale);
        assertEquals(createdSale, retrievedSale);
    }

    @Test
    void testUpdateSale() {
        Date date = new Date();
        double subtotal = 300.0;

        Sale sale = saleControlers.createSale(date, subtotal);
        int id = sale.getId();

        Date newDate = new Date();
        double newSubtotal = 400.0;
        Sale updatedSale = new Sale(newDate, id, newSubtotal);

        assertTrue(saleControlers.updateSale(updatedSale));

        Sale retrievedSale = saleControlers.getSaleById(id);

        assertEquals(newDate, retrievedSale.getDate());
        assertEquals(newSubtotal, retrievedSale.getSubtotal());
    }

    @Test
    void testDeleteSale() {
        Date date = new Date();
        double subtotal = 500.0;

        Sale sale = saleControlers.createSale(date, subtotal);
        int id = sale.getId();

        assertTrue(saleControlers.deleteSale(id));

        Sale retrievedSale = saleControlers.getSaleById(id);

        assertNull(retrievedSale);
    }

    @Test
    void testGetAllSales() {
        saleControlers.createSale(new Date(), 600.0);
        saleControlers.createSale(new Date(), 700.0);

        List<Sale> sales = saleControlers.getAllSales();

        assertEquals(2, sales.size());
    }
}

}