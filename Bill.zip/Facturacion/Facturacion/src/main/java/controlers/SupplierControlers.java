package controlers; 
import models.Supplier; 
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class SupplierControlers {

private List<Supplier> suppliers = new ArrayList<>();
    private int nextId = 1;

    
    public Supplier createSupplier(String name, String address, String phone) {
        Supplier supplier = new Supplier(nextId, name, address, phone);
        suppliers.add(supplier);
        nextId++;
        return supplier;
    }

   
    public Supplier getSupplierById(int id) {
        for (Supplier supplier : suppliers) {
            if (supplier.getId() == id) {
                return supplier;
            }
        }
        return null; 
    }

    
    public boolean updateSupplier(Supplier updatedSupplier) {
        for (int i = 0; i < suppliers.size(); i++) {
            if (suppliers.get(i).getId() == updatedSupplier.getId()) {
                suppliers.set(i, updatedSupplier);
                return true;
            }
        }
        return false; 
    }

   
    public boolean deleteSupplier(int id) {
        for (Supplier supplier : suppliers) {
            if (supplier.getId() == id) {
                suppliers.remove(supplier);
                return true;
            }
        }
        return false; 
    }

    public List<Supplier> getAllSuppliers() {
        return suppliers;
    }

    public class SupplierControlersTest {
    private SupplierControlers supplierControlers;

    @BeforeEach
    void setUp() {
        supplierControlers = new SupplierControlers();
    }

    @Test
    void testCreateSupplier() {
        String name = "Supplier A";
        String address = "123 Main Street";
        String phone = "555-1234";

        Supplier supplier = supplierControlers.createSupplier(name, address, phone);

        assertNotNull(supplier);
        assertEquals(name, supplier.getName());
        assertEquals(address, supplier.getAddress());
        assertEquals(phone, supplier.getPhone());
    }

    @Test
    void testGetSupplierById() {
        String name = "Supplier B";
        String address = "456 Secondary Street";
        String phone = "555-5678";

        Supplier createdSupplier = supplierControlers.createSupplier(name, address, phone);
        int id = createdSupplier.getId();

        Supplier retrievedSupplier = supplierControlers.getSupplierById(id);

        assertNotNull(retrievedSupplier);
        assertEquals(createdSupplier, retrievedSupplier);
    }

    @Test
    void testUpdateSupplier() {
        String name = "Supplier C";
        String address = "789 Tertiary Street";
        String phone = "555-9876";

        Supplier supplier = supplierControlers.createSupplier(name, address, phone);
        int id = supplier.getId();

        String newName = "Supplier D";
        String newAddress = "101 Quaternary Street";
        String newPhone = "555-4321";
        Supplier updatedSupplier = new Supplier(id, newName, newAddress, newPhone);

        assertTrue(supplierControlers.updateSupplier(updatedSupplier));

        Supplier retrievedSupplier = supplierControlers.getSupplierById(id);

        assertEquals(newName, retrievedSupplier.getName());
        assertEquals(newAddress, retrievedSupplier.getAddress());
        assertEquals(newPhone, retrievedSupplier.getPhone());
    }

    @Test
    void testDeleteSupplier() {
        String name = "Supplier E";
        String address = "111 Quintenary Street";
        String phone = "555-1111";

        Supplier supplier = supplierControlers.createSupplier(name, address, phone);
        int id = supplier.getId();

        assertTrue(supplierControlers.deleteSupplier(id));

        Supplier retrievedSupplier = supplierControlers.getSupplierById(id);

        assertNull(retrievedSupplier);
    }

    @Test
    void testGetAllSuppliers() {
        supplierControlers.createSupplier("Supplier F", "222 Sextenary Street", "555-2222");
        supplierControlers.createSupplier("Supplier G", "333 Septenary Street", "555-3333");

        assertEquals(2, supplierControlers.getAllSuppliers().size());
    }
}

}