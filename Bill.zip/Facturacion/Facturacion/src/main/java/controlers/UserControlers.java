package controlers; 
import models.User; 
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class UserControlers {

 private List<User> users = new ArrayList<>();
    private int nextId = 1;

    
    public User createUser(String name, String password, String mail) {
        User user = new User(nextId, name, password, mail);
        users.add(user);
        nextId++;
        return user;
    }

    public User getUserById(int id) {
        for (User user : users) {
            if (user.getId() == id) {
                return user;
            }
        }
        return null; 
    }

    public boolean updateUser(User updatedUser) {
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getId() == updatedUser.getId()) {
                users.set(i, updatedUser);
                return true;
            }
        }
        return false; 

 
    public boolean deleteUser(int id) {
        for (User user : users) {
            if (user.getId() == id) {
                users.remove(user);
                return true;
            }
        }
        return false; 
    }

    public List<User> getAllUsers() {
        return users;
    }

    public class UserControlersTest {
    private UserControlers userControlers;

    @BeforeEach
    void setUp() {
        userControlers = new UserControlers();
    }

    @Test
    void testCreateUser() {
        String name = "John Doe";
        String password = "password123";
        String mail = "john@example.com";

        User user = userControlers.createUser(name, password, mail);

        assertNotNull(user);
        assertEquals(name, user.getName());
        assertEquals(password, user.getPassword());
        assertEquals(mail, user.getMail());
    }

    @Test
    void testGetUserById() {
        String name = "Jane Smith";
        String password = "pass456";
        String mail = "jane@example.com";

        User createdUser = userControlers.createUser(name, password, mail);
        int id = createdUser.getId();

        User retrievedUser = userControlers.getUserById(id);

        assertNotNull(retrievedUser);
        assertEquals(createdUser, retrievedUser);
    }

    @Test
    void testUpdateUser() {
        String name = "Alice Johnson";
        String password = "alicepass";
        String mail = "alice@example.com";

        User user = userControlers.createUser(name, password, mail);
        int id = user.getId();

        String newName = "Bob Williams";
        String newPassword = "bobpass";
        String newMail = "bob@example.com";
        User updatedUser = new User(id, newName, newPassword, newMail);

        assertTrue(userControlers.updateUser(updatedUser));

        User retrievedUser = userControlers.getUserById(id);

        assertEquals(newName, retrievedUser.getName());
        assertEquals(newPassword, retrievedUser.getPassword());
        assertEquals(newMail, retrievedUser.getMail());
    }

    @Test
    void testDeleteUser() {
        String name = "Eve Anderson";
        String password = "evepass";
        String mail = "eve@example.com";

        User user = userControlers.createUser(name, password, mail);
        int id = user.getId();

        assertTrue(userControlers.deleteUser(id));

        User retrievedUser = userControlers.getUserById(id);

        assertNull(retrievedUser);
    }

    @Test
    void testGetAllUsers() {
        userControlers.createUser("Grace Davis", "gracepass", "grace@example.com");
        userControlers.createUser("Michael Wilson", "michaelpass", "michael@example.com");

        assertEquals(2, userControlers.getAllUsers().size());
    }
}

}