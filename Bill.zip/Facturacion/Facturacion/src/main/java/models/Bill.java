package models;

public class Bill {

    private int id;
    private int date;
    private int total;

    public Bill(int id, int date, int total) {
        this.id = id;
        this.date = date;
        this.total = total;
    }

    public Bill() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getDate() {
        return date;
    }

    public void setDate(int date) {
        this.date = date;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    @Override
    public String toString() {
        return "Bill [id=" + id + ", date=" + date + ", total=" + total + "]";
    }

}
