package models;

public class Company {

    private String name;
    private int id;
    private String address;
    private String mail;
    private int phone;

    public Company(String name, int id, String address, String mail, int phone) {
        this.name = name;
        this.id = id;
        this.address = address;
        this.mail = mail;
        this.phone = phone;
    }

    public Company() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    @Override
    public String toString() {
        return "Company [name=" + name + ", id=" + id + ", address=" + address + ", mail=" + mail + ", phone=" + phone
                + "]";
    }

}
