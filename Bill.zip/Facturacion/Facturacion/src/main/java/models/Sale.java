package models;

public class Sale {

    private int date;
    private int id;
    private float subtotal;

    public Sale(int date, int id, float subtotal) {
        this.date = date;
        this.id = id;
        this.subtotal = subtotal;
    }

    public Sale() {
    }

    public int getDate() {
        return date;
    }

    public void setDate(int date) {
        this.date = date;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public float getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(float subtotal) {
        this.subtotal = subtotal;
    }

    @Override
    public String toString() {
        return "Sale [date=" + date + ", id=" + id + ", subtotal=" + subtotal + "]";
    }

}
